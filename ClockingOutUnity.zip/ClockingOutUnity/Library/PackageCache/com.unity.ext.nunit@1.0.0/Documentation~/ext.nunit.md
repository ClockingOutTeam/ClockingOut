# Custom Nunit build to work with Unity

This version of nunit works with all platforms, il2cpp and Mono AOT.

For Nunit Documentation:
https://github.com/nunit/docs/wiki/NUnit-Documentation
